## Compare the models 

library(data.table)
library(plyr)
library(tidyr)
library(ggplot2)

rm(list = ls())

train_data <-  fread("./project/volume/data/interim/train.csv")
train_data <- train_data[, .(id, future_price)]

linreg <- fread('./project/volume/data/external/train_linear.csv')
lasso <- fread('./project/volume/data/external/train_lasso.csv')
ridge <- fread('./project/volume/data/external/train_ridge.csv')

linreg <- data.table(linreg)
lasso <- data.table(lasso)
ridge <- data.table(ridge)

ggplot(train_data, aes(x=future_price)) +
  geom_density(color = "green") +
  geom_density(data = linreg, aes(x=pred), color = "blue") +
  geom_density(data = lasso, aes(x=s1), color = "yellow") +
  geom_density(data = ridge, aes(x=s1), color = "purple") 

train_y <- train_data$future_price
rmse(train_y,linreg$pred)
rmse(train_y,lasso$s1)
rmse(train_y,ridge$s1)


