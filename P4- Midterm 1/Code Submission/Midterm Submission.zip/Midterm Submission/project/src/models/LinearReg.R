## Linear Regression 
library(data.table)
library(caret)
library(Metrics)

rm(list = ls())

## Import data
train <- fread("./project/volume/data/interim/train.csv")
test <- fread("./project/volume/data/interim/test.csv")

## Save id and future_price for later use then remove from the data
train_x <- train$id
train_y <- train$future_price
submit_lin <- data.table(test$id)
train$id <- NULL
train$future_price <- NULL
test$id <- NULL

## Create dummy variables for predictions
dummies <- dummyVars("~.", data=train)

## Apply generated dummyVars to both train and test data sets
train <- data.table(predict(dummies, newdata = train))
train$future_price <- train_y

## Turn values back into dataframe to run predictions later
test <- data.table(predict(dummies, newdata = test))

## Generate model based on the training set values and evaluate the model
lm_fit <- lm(future_price ~., data = train, na.action = na.exclude)
summary(lm_fit)
coef(lm_fit)

## Save the model and dummyVars
saveRDS(dummies,"./project/volume/models/Direction_lm.dummies")
saveRDS(lm_fit,"./project/volume/models/Direction_lm.model")

## Use the model to predict the values on the test data set
test$future_price_pred <- predict(lm_fit, newdata=test, type="response")

## Evaluate rmse of train data set
pred <- predict(lm_fit, newdata=train, type="response")
rmse(train_y,pred)

## Submission
submit_lin$future_price <- test$future_price_pred
setnames(submit_lin, c("V1"), c("id"))

## Post Processing --> replacing negative prices with 0
submit_lin$future_price[submit_lin$future_price < 0] <- 0

## Write dataframe to csv file
fwrite(submit_lin,'./project/volume/data/processed/submit_linreg.csv')

### Used for comparing models
pred <- data.table(pred)
pred$pred[pred$pred < 0] <- 0
fwrite(pred,'./project/volume/data/external/train_linear.csv')
