## LASSO

library(data.table)
library(caret)
library(glmnet)
library(plotmo)
library(Metrics)

rm(list = ls())

## Import data
train <- fread("./project/volume/data/interim/train.csv")
test <- fread("./project/volume/data/interim/test.csv")

## Save id and future_price for later use then remove from the data
train_x <- train$id
train_y <- train$future_price
submit_las <- data.table(test$id)
train$id <- NULL
train$future_price <- NULL
test$id <- NULL

## Create dummy variables for predictions
dummies <- dummyVars("~.", data=train)

## Apply generated dummyVars to both train and test data sets
train <- data.table(predict(dummies, newdata = train))
test <- data.table(predict(dummies, newdata = test))

## Turn both train and test data sets into matrices to generate and predict models
train <- as.matrix(train)
test <- as.matrix(test)

## Generate ridge the model from the training data set to find best lambda
gl_model <- cv.glmnet(train, train_y, alpha = 1, family="gaussian")

## Find the best lambda for the model from the gl_model selection
bestlam <- gl_model$lambda.min

## Refit the model to include the entire data set
gl_model <- glmnet(train, train_y, alpha = 1, family="gaussian")

## Plot the model
plot_glmnet(gl_model)

saveRDS(gl_model,"./project/volume/models/lasso.model")

## Predict the price based on the gl_modela and the best lambda on the test data set
submit_las$future_price <- predict(gl_model, s = bestlam, newx = test)

## Created to find rsme 
pred <- predict(gl_model, s = bestlam, newx = train)

## Submission clean up
setnames(submit_las, c("V1"), c("id"))

## Post Processing --> replacing negative prices with 0
submit_las$future_price[submit_las$future_price < 0] <- 0

## Evaluate rmse of train data set
rmse(train_y,pred)

## Write dataframe to csv file
fwrite(submit_las,'./project/volume/data/processed/submit_lasso.csv')

### Used for comparing models
pred <- data.table(pred)
pred$s1[pred$s1 < 0] <- 0
fwrite(pred,'./project/volume/data/external/train_lasso.csv')