## Test Features with less attributes

# Importing and Cleaning data 
library(data.table)
library(plyr)
library(tidyr)


rm(list = ls())


Sample_Sub <- fread('./project/volume/data/raw/samp_sub.csv')
Start_Test <- fread('./project/volume/data/raw/start_test.csv')
Start_Train <- fread('./project/volume/data/raw/start_train.csv')
Card_Tab <- fread('./project/volume/data/raw/card_tab.csv')


# List current column names
colnames(Card_Tab)
colnames(Start_Train)
colnames(Start_Test)


# Rename Start_Test columns and remove first row
setnames(Start_Test, c("V1"), c("id"))
Start_Test <- Start_Test[id != 'id', .(id)]


# Rename column in Card_Tab
setnames(Card_Tab, c("type", "types"), c("detailed_type", "base_type"))


# Create a master dataframe
master <- Card_Tab[,.SD, .SDcols = !c("card_name", "mana_cost", "detailed_type", "set")]


# Create new features
## Create binary columns
super <- master$supertypes
super <- ifelse(super=="", 0, 1)
master$supertypes <- super

## Create a power-toughness-loyalty and power-toughness rating 
pwrtgh <- master[, .SD, .SDcols = c("id", "power", "toughness", "loyalty")]
pwrtgh$power <- as.integer(pwrtgh$power)
pwrtgh$toughness <- as.integer(pwrtgh$toughness)
pwrtgh$loyalty <- as.integer(pwrtgh$loyalty)
pwrtgh$power[is.na(pwrtgh$power)] <- 0
pwrtgh$toughness[is.na(pwrtgh$toughness)] <- 0
pwrtgh$loyalty[is.na(pwrtgh$loyalty)] <- 0
pwrtgh$ptlcombo <- pwrtgh$power + pwrtgh$toughness + pwrtgh$loyalty
master <- merge(master, pwrtgh[, .SD, .SDcols= c("id", "ptlcombo")], by = c("id"))
master$power <- NULL
master$toughness <- NULL
master$loyalty <- NULL

## Length of text
master$text = sapply(strsplit(master$text, " "), length)

## Turn colors to numeric representations of categorical and list number of colors for each value
master$colors[master$colors == ""] <- NA
master <- separate(master, col="colors", into = c("Color_1", "Color_2", "Color_3", "Color_4", "Color_5"),  sep = " ")
### Turn each categorical variable into number and replace NA values with 0
master$Color_1 <- data.matrix(data.frame(unclass(master$Color_1)))
master$Color_1[is.na(master$Color_1)] <- 0
master$Color_2 <- data.matrix(data.frame(unclass(master$Color_2)))
master$Color_2[is.na(master$Color_2)] <- 0
master$Color_3 <- data.matrix(data.frame(unclass(master$Color_3)))
master$Color_3[is.na(master$Color_3)] <- 0
master$Color_4 <- data.matrix(data.frame(unclass(master$Color_4)))
master$Color_4[is.na(master$Color_4)] <- 0
master$Color_5 <- data.matrix(data.frame(unclass(master$Color_5)))
master$Color_5[is.na(master$Color_5)] <- 0

## Create NULL values
master$subtypes <- NULL
master$set_name <- NULL

## Turn base_types to numeric representations of categorical 
master$base_type <- data.matrix(data.frame(unclass(master$base_type)))

# Creating the test and train sets
train <- unique(merge(Start_Train, master, by = c("id")))
test <- merge(Start_Test, master, by = c("id"))

# Write to interim
fwrite(train, "./project/volume/data/interim/train.csv")
fwrite(test, "./project/volume/data/interim/test.csv")