## Importing and Cleaning data 
library(data.table)

rm(list = ls())

Sample_Sub <- fread('./project/volume/data/raw/samp_sub.csv')
Set_Tab <- fread('./project/volume/data/raw/set_tab.csv')
Start_Test <- fread('./project/volume/data/raw/start_test.csv')
Start_Train <- fread('./project/volume/data/raw/start_train.csv')
Card_Tab <- fread('./project/volume/data/raw/card_tab.csv')

## List current column names
colnames(Card_Tab)
colnames(Set_Tab)
colnames(Start_Train)
colnames(Start_Test)

## Rename Start_Test columns and remove first row
setnames(Start_Test, c("V1"), c("id"))
Start_Test <- Start_Test[id != 'id', .(id)]

## Rename column in Set_Tab
setnames(Set_Tab, c("set_names", "type"), c("set_name", "pack_type"))

# Rename column in Card_Tab
setnames(Card_Tab, c("type", "types"), c("detailed_type", "base_type"))

## Merge Card_Tab and Set_Tab
master <- merge(Card_Tab, Set_Tab, by = c("set", "set_name"))

## Removing test feature
## Remove as only provides information about if the subsetted dataframe is part of the test set or train set
master <- master[,.SD, .SDcols=!c("mana_cost", "card_name", )]

## Create new features
## Length of text
master$text = sapply(strsplit(master$text, " "), length)

## Split colors
#master <- 

## split detailed_type
#master <- 

## Power Toughness rarity
#master <- 

## Creating the test and train sets
train <- merge(Start_Train, master, by = c("id"),no.dups = TRUE, all.x = TRUE,all.y = FALSE)
test <- merge(Start_Test, master, by = c("id"))

## Write to interim
fwrite(train, "./project/volume/data/interim/train.csv")
fwrite(test, "./project/volume/data/interim/test.csv")