# Run Main.R
source('./project/src/features/splitting_data.R')
source('./project/src/models/Linear_Regression_Model.R')