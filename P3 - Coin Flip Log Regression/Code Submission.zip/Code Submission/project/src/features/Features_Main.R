## Features
rm(list=ls())

library(data.table)
#library()

Train <- fread('./project/volume/data/raw/train_file.csv')
Test <- fread('./project/volume/data/raw/test_file.csv')
#Sample_Sub <- fread('./project/volume/data/raw/samp_sub.csv')
Train <- Train[, SumVal:= rowSums(.SD), .SDcols = !c("id", "result")]
Train <- Train[, GreaterThanHalf:= fifelse(SumVal>5, 'y', 'n')]
Train$SumVal <- NULL
Test <- Test[, SumVal:= rowSums(.SD), .SDcols = !c("id")]
Test <- Test[, GreaterThanHalf:= fifelse(SumVal>5, 'y', 'n')]
Test$SumVal <- NULL

fwrite(Train, './project/volume/data/interim/modified_train.csv')
fwrite(Test, './project/volume/data/interim/modified_test.csv')