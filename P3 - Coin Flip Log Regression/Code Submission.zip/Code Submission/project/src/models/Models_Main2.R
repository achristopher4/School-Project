## Models
rm(list=ls())

library(caret) 
library(data.table)
library(Metrics)


Train <- fread('./project/volume/data/interim/modified_train.csv')
Test <- fread('./project/volume/data/interim/modified_test.csv')


train_y <- Train$result
train_x <- Train$id
test_id <- data.table(Test$id)
setnames(test_id, "V1", "id")
Train$id <- NULL
Test$id <- NULL
Train$result <- NULL

dummies <- dummyVars("~.", data=Train)
Train <- predict(dummies, newdata = Train)
Test <- predict(dummies, newdata = Test)

Train <- data.table(Train)
Train$result <- train_y
Test <- data.table(Test)

glm_fit <- glm(result ~., family = binomial, data = Train)

summary(glm_fit)
coef(glm_fit)

saveRDS(dummies,"./project/volume/models/Direction_lm.dummies2")
saveRDS(glm_fit,"./project/volume/models/Direction_glm.model2")

Test$prediction <- predict(glm_fit, newdata = Test, type = "response")



## Attempt 2
submission2 <- test_id
submission2$result <- Test[,.(prediction)]

fwrite(submission2, "./project/volume/data/processed/submission2.csv")