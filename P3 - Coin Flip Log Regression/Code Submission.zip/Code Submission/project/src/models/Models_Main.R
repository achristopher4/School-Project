## Models
rm(list=ls())

library(caret) 
library(data.table)
library(Metrics)

Train <- fread('./project/volume/data/raw/train_file.csv')
Test <- fread('./project/volume/data/raw/test_file.csv')


train_y <- Train$result
train_x <- Train$id
test_id <- data.table(Test$id)
setnames(test_id, "V1", "id")
Train$id <- NULL
Test$id <- NULL
Train$result <- NULL

dummies <- dummyVars("~.", data=Train)
Train <- predict(dummies, newdata = Train)
Test <- predict(dummies, newdata = Test)

Train <- data.table(Train)
Train$result <- train_y
Test <- data.table(Test)

glm_fit <- glm(result ~., family = binomial, data = Train)

summary(glm_fit)
coef(glm_fit)

saveRDS(dummies,"./project/volume/models/Direction_lm.dummies")
saveRDS(glm_fit,"./project/volume/models/Direction_glm.model")

Test$prediction <- predict(glm_fit, newdata = Test, type = "response")


## Attempt 1
submission <- test_id
submission$result <- Test[,.(prediction)]

fwrite(submission, "./project/volume/data/processed/submission.csv")



